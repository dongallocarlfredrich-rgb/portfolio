const DEFAULT_DATA = {
  books: [
    { id: "B001", title: "Introduction to Programming", author: "John Smith", category: "Programming" },
    { id: "B002", title: "Web Development Basics", author: "Maria Santos", category: "Web Development" },
    { id: "B003", title: "Database Management", author: "David Cruz", category: "Database" },
    { id: "B004", title: "Computer Networks", author: "James Wilson", category: "Networking" },
    { id: "B005", title: "UI/UX Design Principles", author: "Anna Reyes", category: "Design" }
  ],
  members: [
    { id: "M001", name: "Juan Dela Cruz", email: "juan@email.com", phone: "09123456789", joined: "2026-07-12" },
    { id: "M002", name: "Maria Santos", email: "maria@email.com", phone: "09987654321", joined: "2026-07-18" },
    { id: "M003", name: "Carlos Reyes", email: "carlos@email.com", phone: "09112223344", joined: "2026-08-01" }
  ],
  transactions: [
    { id: "T001", bookId: "B001", memberId: "M001", borrowed: "2026-08-10", due: "2026-08-17", status: "Borrowed" },
    { id: "T002", bookId: "B003", memberId: "M002", borrowed: "2026-08-08", due: "2026-08-15", status: "Borrowed" }
  ]
};

let data = JSON.parse(localStorage.getItem("libraryData")) || DEFAULT_DATA;
const save = () => localStorage.setItem("libraryData", JSON.stringify(data));

const $ = (id) => document.getElementById(id);
const today = () => new Date().toISOString().slice(0, 10);

function book(id) { return data.books.find(x => x.id === id); }
function member(id) { return data.members.find(x => x.id === id); }

function nextId(prefix, list) {
  const nums = list.map(x => parseInt(x.id.replace(/\D/g, "")) || 0);
  return prefix + String(Math.max(0, ...nums) + 1).padStart(3, "0");
}

function showSection(name) {
  document.querySelectorAll(".content-section").forEach(s => s.classList.remove("active-section"));
  document.querySelectorAll(".nav-link").forEach(n => n.classList.remove("active"));
  $(name).classList.add("active-section");

  const nav = document.querySelector(`.nav-link[data-section="${name}"]`);
  if (nav) nav.classList.add("active");

  const titles = {
    dashboard: ["Dashboard", "Welcome back, Librarian."],
    books: ["Books", "Manage your library collection."],
    members: ["Members", "Manage registered library members."],
    borrow: ["Borrow / Return", "Track borrowed and returned books."]
  };

  $("pageTitle").textContent = titles[name][0];
  $("pageSubtitle").textContent = titles[name][1];
  renderAll();
}

function renderDashboard() {
  $("totalBooks").textContent = data.books.length;
  $("totalMembers").textContent = data.members.length;
  $("borrowedBooks").textContent =
    data.transactions.filter(t => t.status === "Borrowed").length;
  $("availableBooks").textContent =
    data.books.length - data.transactions.filter(t => t.status === "Borrowed").length;
}

function renderBooks(filter = "") {
  const rows = data.books.filter(b =>
    `${b.id} ${b.title} ${b.author} ${b.category}`
      .toLowerCase()
      .includes(filter.toLowerCase())
  );

  const borrowedIds = new Set(
    data.transactions
      .filter(t => t.status === "Borrowed")
      .map(t => t.bookId)
  );

  $("booksTable").innerHTML = rows.length
    ? rows.map(b => {
        const isBorrowed = borrowedIds.has(b.id);
        return `<tr>
          <td>${b.id}</td>
          <td><strong>${b.title}</strong></td>
          <td>${b.author}</td>
          <td>${b.category}</td>
          <td><span class="badge ${isBorrowed ? "borrowed" : "available"}">
            ${isBorrowed ? "Borrowed" : "Available"}
          </span></td>
          <td>
            <button class="action-btn" data-edit-book="${b.id}">Edit</button>
            <button class="action-btn delete" data-delete-book="${b.id}">Delete</button>
          </td>
        </tr>`;
      }).join("")
    : `<tr><td colspan="6"><div class="empty">No books found.</div></td></tr>`;
}

function renderMembers(filter = "") {
  const rows = data.members.filter(m =>
    `${m.id} ${m.name} ${m.email} ${m.phone}`
      .toLowerCase()
      .includes(filter.toLowerCase())
  );

  $("membersTable").innerHTML = rows.length
    ? rows.map(m => `<tr>
      <td>${m.id}</td>
      <td><strong>${m.name}</strong></td>
      <td>${m.email}</td>
      <td>${m.phone}</td>
      <td>${m.joined}</td>
      <td>
        <button class="action-btn" data-edit-member="${m.id}">Edit</button>
        <button class="action-btn delete" data-delete-member="${m.id}">Delete</button>
      </td>
    </tr>`).join("")
    : `<tr><td colspan="6"><div class="empty">No members found.</div></td></tr>`;
}

function renderTransactions(filter = "") {
  // Transaction rendering section from the project.
}
